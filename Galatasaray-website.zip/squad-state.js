export const slots = [
  {id:'st',label:'Santrfor',short:'SNT'},
  {id:'lw',label:'Sol kanat',short:'SLK'}, {id:'am',label:'Ofansif orta saha',short:'MOO'}, {id:'rw',label:'Sağ kanat',short:'SĞK'},
  {id:'dm1',label:'Sol merkez orta saha',short:'MO'}, {id:'dm2',label:'Sağ merkez orta saha',short:'MO'},
  {id:'lb',label:'Sol bek',short:'SLB'}, {id:'cb1',label:'Sol stoper',short:'STP'}, {id:'cb2',label:'Sağ stoper',short:'STP'}, {id:'rb',label:'Sağ bek',short:'SĞB'},
  {id:'gk',label:'Kaleci',short:'KL'},
];
export const rows = [['st'],['lw','am','rw'],['dm1','dm2'],['lb','cb1','cb2','rb'],['gk']];
export const lastEleven = {"st":"45","lw":"53","am":"83","rw":"11","dm1":"34","dm2":"99","lb":"4","cb1":"42","cb2":"6","rb":"7","gk":"1"};
export function sanitiseLineup(value, players) {
  const result = {}, used = new Set(), ids = new Set(players.map(p=>p.id));
  if (!value || typeof value !== 'object' || Array.isArray(value)) return result;
  for (const slot of slots) {
    const id = value[slot.id];
    if (typeof id === 'string' && ids.has(id) && !used.has(id)) { result[slot.id] = id; used.add(id); }
  }
  return result;
}
export function choosePlayer(lineup, slotId, playerId, players) {
  if (!slots.some(s=>s.id===slotId) || !players.some(p=>p.id===playerId)) throw Error('invalid-selection');
  if (Object.entries(lineup).some(([slot,id])=>slot!==slotId && id===playerId)) throw Error('already-selected');
  return {...lineup,[slotId]:playerId};
}
