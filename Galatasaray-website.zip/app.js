const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
clearTimeout(window.motionFallback);
if (!reducedMotion.matches && scrollY < 100) document.documentElement.classList.add('motion');
else document.documentElement.classList.remove('motion');

const menuButton = document.querySelector('.menu-toggle');
const menu = document.querySelector('#mobile-menu');
function closeMenu() { menu.hidden = true; menuButton.setAttribute('aria-expanded', 'false'); menuButton.setAttribute('aria-label', 'Menüyü aç'); }
menuButton.addEventListener('click', () => { const open = menuButton.getAttribute('aria-expanded') !== 'true'; menu.hidden = !open; menuButton.setAttribute('aria-expanded', String(open)); menuButton.setAttribute('aria-label', open ? 'Menüyü kapat' : 'Menüyü aç'); });
menu.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !menu.hidden) { closeMenu(); menuButton.focus(); } });
matchMedia('(min-width:1000px)').addEventListener('change', closeMenu);

const kickoff = new Date('2026-10-30T20:00:00+03:00').getTime();
const dateLabel = document.querySelector('#countdown-date');
function updateCountdown() {
  const distance = Math.max(0, kickoff - Date.now());
  const values = { days: Math.floor(distance / 86400000), hours: Math.floor(distance / 3600000) % 24, minutes: Math.floor(distance / 60000) % 60, seconds: Math.floor(distance / 1000) % 60 };
  for (const [unit, value] of Object.entries(values)) document.querySelector(`[data-count="${unit}"]`).textContent = String(value).padStart(2, '0');
  dateLabel.textContent = distance > 0 ? '30 Ekim 2026 · 20.00 TSİ · Konyaspor – Galatasaray' : 'Planlanan maç saati geldi. Güncel program için resmî fikstürü kontrol edin.';
  return distance;
}
let countdownInterval;
function startCountdown() { clearInterval(countdownInterval); if (updateCountdown() > 0) countdownInterval = setInterval(() => { if (updateCountdown() === 0) clearInterval(countdownInterval); }, 1000); }
startCountdown();
document.addEventListener('visibilitychange', () => { if (document.hidden) clearInterval(countdownInterval); else startCountdown(); });

const slider = document.querySelector('#kit-slider');
const kitCards = [...slider.querySelectorAll('.kit-card')];
const previous = document.querySelector('[data-slide="-1"]');
const next = document.querySelector('[data-slide="1"]');
function updateSlider() {
  const index = Math.round(slider.scrollLeft / (kitCards[0].offsetWidth + parseFloat(getComputedStyle(slider).gap)));
  previous.disabled = slider.scrollLeft < 3;
  next.disabled = slider.scrollLeft >= slider.scrollWidth - slider.clientWidth - 3;
  document.querySelector('#slider-position').textContent = `${String(index + 1).padStart(2, '0')} — 03`;
}
document.querySelectorAll('[data-slide]').forEach(button => button.addEventListener('click', () => slider.scrollBy({ left: Number(button.dataset.slide) * (kitCards[0].offsetWidth + parseFloat(getComputedStyle(slider).gap)), behavior: reducedMotion.matches ? 'instant' : 'smooth' })));
slider.addEventListener('scroll', updateSlider, { passive: true });
new ResizeObserver(updateSlider).observe(slider);
slider.addEventListener('keydown', e => { if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); slider.scrollBy({left: (e.key === 'ArrowRight' ? 1 : -1) * kitCards[0].offsetWidth, behavior: reducedMotion.matches ? 'instant' : 'smooth'}); } });
updateSlider();

const dialog = document.querySelector('#plan-dialog');
const descriptions = { Fan: 'Taraftar: dijital taraftar kartı, maç günü bülteni ve duvar kâğıtları için örnek paket fikri.', 'Tribün': 'Tribün: Taraftar paketine ek maç günü içerikleri ve atkı içeren örnek paket fikri.', Legacy: 'Efsane: Tribün paketine ek aile paketi ve kişiselleştirilmiş hatıra içeren örnek paket fikri.' };
document.querySelectorAll('[data-plan]').forEach(button => button.addEventListener('click', () => { document.querySelector('#dialog-title').textContent = ({Fan:'Taraftar',Tribün:'Tribün',Legacy:'Efsane'})[button.dataset.plan]; document.querySelector('#dialog-copy').textContent = descriptions[button.dataset.plan]; dialog.showModal(); }));
dialog.addEventListener('click', e => { if (e.target === dialog) { const box = dialog.getBoundingClientRect(); if (e.clientX < box.left || e.clientX > box.right || e.clientY < box.top || e.clientY > box.bottom) dialog.close(); } });

// Missing placeholder media is never requested as a video. The local poster remains visible.
const video = document.querySelector('#stadium-video');
const videoToggle = document.querySelector('#video-toggle');
let userPaused = false;
async function loadVideo() {
  if (reducedMotion.matches || navigator.connection?.saveData) return;
  try {
    const response = await fetch(video.dataset.src, { method: 'HEAD' });
    if (!response.ok || !response.headers.get('content-type')?.startsWith('video/')) return;
    video.src = video.dataset.src;
    video.muted = true;
    await video.play();
    videoToggle.hidden = false;
  } catch { /* Autoplay restrictions or absent media: keep the poster. */ }
}
video.addEventListener('playing', () => { video.classList.add('is-playing'); videoToggle.textContent = 'Ⅱ'; videoToggle.setAttribute('aria-label', 'Arka plan videosunu duraklat'); });
video.addEventListener('pause', () => { videoToggle.textContent = '▷'; videoToggle.setAttribute('aria-label', 'Arka plan videosunu oynat'); });
video.addEventListener('error', () => { video.classList.remove('is-playing'); videoToggle.hidden = true; });
videoToggle.addEventListener('click', () => { userPaused = !video.paused; if (video.paused) video.play().catch(() => {}); else video.pause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) video.pause(); else if (video.src && !userPaused && !reducedMotion.matches) video.play().catch(() => {}); });
reducedMotion.addEventListener('change', () => { if (reducedMotion.matches) { video.pause(); document.documentElement.classList.remove('motion'); } });

function enhance() {
  loadVideo();
  if (reducedMotion.matches || !document.documentElement.classList.contains('motion')) return;
  const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } }), { threshold: .08 });
  document.querySelectorAll('.section-head').forEach(element => { if (element.getBoundingClientRect().top > innerHeight) { element.classList.add('reveal-ready'); observer.observe(element); } });
}
if ('requestIdleCallback' in window) requestIdleCallback(enhance, { timeout: 1800 }); else setTimeout(enhance, 300);
