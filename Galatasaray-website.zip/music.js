// Actual Galatasaray chant excerpt: Çocukluk Aşkımsın.
const musicButton = document.querySelector('#music-toggle');
const musicLabel = document.querySelector('#music-label');
const volume = document.querySelector('#music-volume');
const audio = document.querySelector('#supporter-audio');
const preferenceKey = 'uluks-gala-tribun-enabled';
let enabled = true, pending = false, attempting = false;
try { enabled = localStorage.getItem(preferenceKey) !== 'false'; } catch {}
audio.autoplay = enabled && !document.hidden;
if (!enabled || document.hidden) audio.pause();
audio.volume = Number(volume.value) / 100;
function savePreference() { try { localStorage.setItem(preferenceKey, String(enabled)); } catch {} }
function updateUi() {
  const playing = !audio.paused && !audio.ended;
  musicButton.setAttribute('aria-pressed', String(playing));
  musicButton.setAttribute('aria-label', playing ? 'Tribün sesini kapat' : 'Tribün sesini aç');
  musicLabel.textContent = playing ? 'Tribün açık' : 'Tribünü aç';
  musicButton.title = pending ? 'Tarayıcı ses için ilk dokunuşunuzu bekliyor' : 'Çocukluk Aşkımsın · Galatasaray tribün kaydı';
}
async function start() {
  if (!enabled || document.hidden || attempting) return;
  attempting = true;
  try { await audio.play(); pending = false; }
  catch { pending = true; }
  finally { attempting = false; updateUi(); }
}
musicButton.addEventListener('click', () => {
  if (!audio.paused) { enabled = false; pending = false; audio.pause(); }
  else { enabled = true; start(); }
  savePreference(); updateUi();
});
volume.addEventListener('input', () => { audio.volume = Number(volume.value) / 100; });
audio.addEventListener('playing', () => { pending = false; updateUi(); });
audio.addEventListener('pause', updateUi);
audio.addEventListener('error', () => { pending = false; updateUi(); musicLabel.textContent = 'Ses yüklenemedi'; });
function unlock(event) { if (event.target.closest?.('#music-toggle')) return; if (enabled && audio.paused) start(); }
document.addEventListener('pointerdown', unlock, { passive: true });
document.addEventListener('keydown', unlock);
document.addEventListener('visibilitychange', () => { if (document.hidden) audio.pause(); else if (enabled) start(); });
updateUi();
if (enabled) start();
