import {players, ROSTER_CHECKED} from './squad-data.js';
import {slots, rows, lastEleven, sanitiseLineup, choosePlayer} from './squad-state.js';

const section = document.querySelector('#build-eleven');
const pitch = section.querySelector('#builder-pitch');
const status = section.querySelector('#builder-status');
const count = section.querySelector('#builder-count');
const summary = section.querySelector('#builder-summary');
const picker = document.querySelector('#player-picker');
const pickerTitle = picker.querySelector('#picker-title');
const search = picker.querySelector('#player-search');
const results = picker.querySelector('#player-options');
const resultCount = picker.querySelector('#picker-results-count');
const removeButton = picker.querySelector('#remove-player');
const storageKey = 'uluks-gala-favourite-eleven-v1';
const playerById = new Map(players.map(p=>[p.id,p]));
let lineup = {}, activeSlot, group = 'Tümü';
try { lineup = sanitiseLineup(JSON.parse(localStorage.getItem(storageKey)),players); } catch {}
const fold = value => value.toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replaceAll('ı','i');
function element(tag,className,text) { const node=document.createElement(tag); if(className)node.className=className;if(text!==undefined)node.textContent=text;return node; }
function persist() {
  try { localStorage.setItem(storageKey,JSON.stringify(lineup)); section.querySelector('#builder-save-note').textContent='Kadron bu tarayıcıda otomatik saklanır.'; }
  catch { section.querySelector('#builder-save-note').textContent='Bu tarayıcıda otomatik kayıt kullanılamıyor; sayfa açıkken seçim yapabilirsin.'; }
}
const buttons = new Map();
for (const rowIds of rows) {
  const row=element('div','builder-row');
  for (const id of rowIds) {
    const button=element('button','builder-slot');button.type='button';button.dataset.slot=id;
    button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-controls','player-picker');
    button.addEventListener('click',()=>openPicker(id));buttons.set(id,button);row.append(button);
  }
  pitch.append(row);
}
function renderLineup() {
  const total = Object.keys(lineup).length;
  count.textContent=`${total} / 11`;
  section.querySelector('#reset-lineup').disabled=total===0;
  summary.replaceChildren();
  for (const slot of slots) {
    const button=buttons.get(slot.id), player=playerById.get(lineup[slot.id]);
    button.replaceChildren();button.classList.toggle('is-picked',!!player);
    button.setAttribute('aria-label',`${slot.label}: ${player ? player.name+', değiştir' : 'oyuncu seç'}`);
    const position=element('span','slot-position',slot.short);button.append(position);
    if (player) {
      const image=element('img','slot-portrait');image.src=player.image;image.alt='';image.width=112;image.height=118;image.loading='lazy';
      button.append(image,element('span','slot-name',player.name==='Ederson Santana de Moraes'?'Ederson':player.name),element('span','slot-action','Değiştir'));
    } else {
      button.append(element('span','slot-plus','+'),element('span','slot-name','Oyuncu seç'));
    }
    const item=element('li');item.append(element('span','',slot.label),element('strong','',player ? player.name : 'Henüz seçilmedi'));summary.append(item);
  }
  section.querySelector('#builder-complete').hidden=total!==11;
}
function renderOptions() {
  const query=fold(search.value.trim());
  const positionGroup=activeSlot==='gk'?'Kaleci':['lb','cb1','cb2','rb'].includes(activeSlot)?'Defans':['st','lw','rw'].includes(activeSlot)?'Forvet':'Orta saha';
  const matches=players.filter(p=>(group==='Tümü'||p.group===group)&&(!query||fold(`${p.name} ${p.number}`).includes(query))).sort((a,b)=>Number(b.group===positionGroup)-Number(a.group===positionGroup));
  results.replaceChildren();resultCount.textContent=`${matches.length} oyuncu`;
  if(!matches.length){results.append(element('p','picker-empty','Oyuncu bulunamadı. Başka bir ad veya forma numarası dene.'));return;}
  for(const player of matches){
    const usedSlot=slots.find(s=>s.id!==activeSlot&&lineup[s.id]===player.id);
    const isCurrent=lineup[activeSlot]===player.id;
    const item=element('li');const button=element('button','player-option');button.type='button';button.dataset.playerId=player.id;
    button.disabled=!!usedSlot;button.classList.toggle('is-current',isCurrent);
    button.setAttribute('aria-label',`${player.name}, ${player.group}, ${player.number} numara${usedSlot?', '+usedSlot.label+' pozisyonunda seçili':isCurrent?', bu pozisyonda seçili':''}`);
    const image=element('img','option-portrait');image.src=player.image;image.alt='';image.width=56;image.height=60;image.loading='lazy';
    const text=element('span','option-text');text.append(element('strong','',player.name),element('span','',`#${player.number} · ${player.group}`));
    button.append(image,text,element('span','option-marker',usedSlot?'Seçili':isCurrent?'✓':'+'));
    if(usedSlot)text.append(element('small','',usedSlot.label+' pozisyonunda seçili'));
    button.addEventListener('click',()=>{
      try { lineup=choosePlayer(lineup,activeSlot,player.id,players);persist();renderLineup();picker.close();status.textContent=`${slots.find(s=>s.id===activeSlot).label}: ${player.name} seçildi. ${Object.keys(lineup).length} / 11 oyuncu.`; }
      catch { status.textContent='Bu oyuncu kadroda zaten var. Önce diğer pozisyondan kaldır.'; }
    });
    item.append(button);results.append(item);
  }
}
function openPicker(id) {
  activeSlot=id;group='Tümü';search.value='';pickerTitle.textContent=slots.find(s=>s.id===id).label;
  picker.querySelectorAll('[data-group]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.group==='Tümü')));
  removeButton.hidden=!lineup[id];renderOptions();results.scrollTop=0;picker.showModal();
}
search.addEventListener('input',renderOptions);
picker.querySelectorAll('[data-group]').forEach(button=>button.addEventListener('click',()=>{
  group=button.dataset.group;picker.querySelectorAll('[data-group]').forEach(other=>other.setAttribute('aria-pressed',String(other===button)));renderOptions();results.scrollTop=0;
}));
picker.querySelector('#close-picker').addEventListener('click',()=>picker.close());
picker.addEventListener('click',event=>{
  if(event.target!==picker)return;const rect=picker.getBoundingClientRect();
  if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)picker.close();
});
picker.addEventListener('close',()=>buttons.get(activeSlot)?.focus({preventScroll:true}));
removeButton.addEventListener('click',()=>{const position=slots.find(s=>s.id===activeSlot).label;delete lineup[activeSlot];persist();renderLineup();picker.close();status.textContent=`${position} boşaltıldı.`;});
section.querySelector('#reset-lineup').addEventListener('click',()=>{lineup={};persist();renderLineup();status.textContent='Kadro sıfırlandı. Yeni ilk 11’ini seçebilirsin.';});
section.querySelector('#use-last-eleven').addEventListener('click',()=>{lineup=sanitiseLineup(lastEleven,players);persist();renderLineup();status.textContent='Son maçın ilk 11’i yüklendi. Değiştirmek istediğin pozisyona dokun.';});
section.querySelector('#squad-checked').textContent=`${players.length} oyuncu · Kaynak: Galatasaray SK · ${ROSTER_CHECKED}`;
renderLineup();section.querySelector('#builder-interface').hidden=false;

