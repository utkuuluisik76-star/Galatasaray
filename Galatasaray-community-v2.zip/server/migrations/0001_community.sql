CREATE TABLE IF NOT EXISTS monthly_votes (
  period TEXT NOT NULL,
  voter TEXT NOT NULL,
  player_id TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (period, voter)
);
CREATE INDEX IF NOT EXISTS monthly_results ON monthly_votes(period, player_id);
CREATE TABLE IF NOT EXISTS lineup_votes (
  period TEXT NOT NULL,
  voter TEXT NOT NULL,
  lineup TEXT NOT NULL CHECK (json_valid(lineup)),
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (period, voter)
);
