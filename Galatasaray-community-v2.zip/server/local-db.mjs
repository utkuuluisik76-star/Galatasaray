import {DatabaseSync} from 'node:sqlite';
import {readFileSync,mkdirSync} from 'node:fs';
export function openDatabase(filename=new URL('../data/community.sqlite',import.meta.url)){
 if(filename!==':memory:')mkdirSync(new URL('../data/',import.meta.url),{recursive:true});
 const sqlite=new DatabaseSync(filename);
 sqlite.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8'));
 sqlite.exec('PRAGMA journal_mode=WAL;');
 return {sqlite,prepare(sql){let values=[];const s=sqlite.prepare(sql);return{bind(...args){values=args;return this;},async all(){return{results:s.all(...values)};},async first(){return s.get(...values)||null;},async run(){const r=s.run(...values);return{meta:{changes:r.changes}};}};}};
}
