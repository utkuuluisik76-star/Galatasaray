import {players} from '../dist/squad-data.js';
import {slots,sanitiseLineup} from '../dist/squad-state.js';
const ids=new Set(players.map(p=>p.id));
export const fixture={id:'2026-10-30-konyaspor-galatasaray',label:'Konyaspor – Galatasaray · 30 Ekim 2026',closes:'2026-10-30T20:00:00+03:00'};
function periodFor(now){const d=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit'}).formatToParts(new Date(now));return d.find(x=>x.type==='year').value+'-'+d.find(x=>x.type==='month').value;}
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Robots-Tag':'noindex, nofollow'};
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers});
async function hash(token,period){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(`gala-v1:${period}:${token}`));return Array.from(new Uint8Array(bytes),n=>n.toString(16).padStart(2,'0')).join('');}
async function readJson(request){const reader=request.body?.getReader();if(!reader)throw Error('body');let size=0;const chunks=[];while(true){const{done,value}=await reader.read();if(done)break;size+=value.length;if(size>8192){await reader.cancel();throw Error('body')}chunks.push(value);}const bytes=new Uint8Array(size);let i=0;for(const c of chunks){bytes.set(c,i);i+=c.length;}return JSON.parse(new TextDecoder().decode(bytes));}
export async function handleApi(request,db,now=Date.now()){
 const url=new URL(request.url),route=url.pathname,period=periodFor(now),open=now<new Date(fixture.closes).getTime();
 if(!route.startsWith('/api/'))return null;
 if(request.method==='OPTIONS')return new Response(null,{status:405,headers:{Allow:'GET, POST'}});
 if(!db)return json({error:'Oylama şu anda kullanılamıyor. Daha sonra tekrar dene.'},503);
 try{
  if(route==='/api/community'&&request.method==='GET'){
   const month=await db.prepare('SELECT player_id AS playerId, COUNT(*) AS votes FROM monthly_votes WHERE period=? GROUP BY player_id ORDER BY votes DESC, player_id').bind(period).all();
   const selections=await db.prepare('SELECT j.key AS position, j.value AS playerId, COUNT(*) AS votes FROM lineup_votes l, json_each(l.lineup) j WHERE l.period=? GROUP BY j.key,j.value ORDER BY votes DESC,j.key,j.value').bind(fixture.id).all();
   const total=await db.prepare('SELECT COUNT(*) AS total FROM lineup_votes WHERE period=?').bind(fixture.id).first();
   return json({period,fixture:{...fixture,open},monthly:{total:month.results.reduce((n,r)=>n+r.votes,0),results:month.results},lineups:{total:total.total,results:selections.results}});
  }
  if(route==='/api/community.csv'&&request.method==='GET'){
   const stats=await handleApi(new Request(url.origin+'/api/community'),db,now),data=await stats.json();
   const quote=v=>'"'+String(v).replaceAll('"','""')+'"';
   const rows=[['type','period','position','player_id','player','votes'],...data.monthly.results.map(r=>['monthly',period,'',r.playerId,players.find(p=>p.id===r.playerId)?.name||'',r.votes]),...data.lineups.results.map(r=>['lineup',fixture.id,slots.find(s=>s.id===r.position)?.label||r.position,r.playerId,players.find(p=>p.id===r.playerId)?.name||'',r.votes])];
   return new Response('\uFEFF'+rows.map(r=>r.map(quote).join(',')).join('\r\n'),{headers:{...headers,'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="galatasaray-taraftar-sonuclari.csv"'}});
  }
  if(!['/api/vote/monthly','/api/vote/lineup'].includes(route))return json({error:'Bulunamadı.'},404);
  if(request.method!=='POST')return json({error:'POST gerekli.'},405);
  if(request.headers.get('origin')!==url.origin)return json({error:'İstek kaynağı geçersiz.'},403);
  if(!request.headers.get('content-type')?.startsWith('application/json'))return json({error:'JSON gerekli.'},415);
  let body;try{body=await readJson(request);}catch{return json({error:'Geçersiz istek.'},400);}
  if(!body||typeof body!=='object'||typeof body.token!=='string'||!/^[-a-zA-Z0-9_]{32,80}$/.test(body.token))return json({error:'Tarayıcı anahtarı geçersiz.'},400);
  let table,ballot,key;
  if(route.endsWith('/monthly')){
   if(body.period!==period)return json({error:'Oylama ayı değişti. Sayfayı yenile.'},409);
   if(!ids.has(body.playerId))return json({error:'Oyuncu bulunamadı.'},400);
   table='monthly_votes';ballot=body.playerId;key=period;
  }else{
   if(body.period!==fixture.id)return json({error:'Bu maç için oylama geçerli değil.'},409);
   if(!open)return json({error:'Bu maçın kadro oylaması kapandı.'},409);
   const clean=sanitiseLineup(body.lineup,players);
   if(!body.lineup||Object.keys(body.lineup).length!==11||Object.keys(clean).length!==11)return json({error:'11 farklı oyuncuyla tüm pozisyonları doldur.'},400);
   table='lineup_votes';ballot=JSON.stringify(clean);key=fixture.id;
  }
  const voter=await hash(body.token,key),col=table==='monthly_votes'?'player_id':'lineup',seconds=Math.floor(now/1000);
  const result=await db.prepare(`INSERT INTO ${table}(period,voter,${col},updated_at) VALUES(?,?,?,?) ON CONFLICT(period,voter) DO UPDATE SET ${col}=excluded.${col},updated_at=excluded.updated_at WHERE ${table}.updated_at<=excluded.updated_at-2`).bind(key,voter,ballot,seconds).run();
  if(!result.meta.changes)return json({error:'Biraz bekleyip tekrar dene.'},429);
  return json({ok:true,period:key});
 }catch{return json({error:'Oy kaydedilemedi. Lütfen daha sonra tekrar dene.'},503);}
}
