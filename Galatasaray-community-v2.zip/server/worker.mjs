import {handleApi} from './api.mjs';
export default {async fetch(request,env){
 const api=await handleApi(request,env.DB);if(api)return api;
 const url=new URL(request.url);
 if(url.pathname==='/media/stadium-drone.mp4')return new Response(null,{status:204});
 return env.ASSETS.fetch(request);
}};
