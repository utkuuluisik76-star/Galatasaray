# Bronnen — gecontroleerd 29 oktober 2026

- Officiële selectie en portretten: https://www.galatasaray.org/pl/futbol-takim-kadrosu/9
- Laatste basiself, score, doelpunten en persgalerij: https://www.galatasaray.org/haber/futbol/derbide-uc-puan-bizim/61231
- Volgende wedstrijd: kalender op https://www.galatasaray.org/anasayfa (30 oktober, 20.00, Konyaspor uit).
- Seizoensschema: https://www.galatasaray.org/haber/futbol/galatasarayin-super-lig-2026-2027-sezonu-fiksturu-belli-oldu/60565
- Officieel logo: https://www.galatasaray.org/assets/img/gs_logo.png
- Productbeelden: GSStore-homepage, 2026/27 shirtkiezer; exacte beeld-URL’s in kits.json.
- Supportersaudio: https://dijitalesik.com/galatasaray-zil-sesleri/ ; exact bestand in audio-source.txt. Geen eigen of officieel clubgelabelde opname.

Fotoselectie uit de officiële derbygalerij: hero foto 26 (golvreugde), doelpuntsectie foto 15 (Osimhen bij een luchtduel), teamfoto 0. Exacte URL’s in gallery.json. De actieafbeelding wordt als wedstrijdmoment getoond, niet als bewezen beeld van een specifieke goal.

Club- en productbeelden blijven eigendom van hun respectieve rechthebbenden. Dit is een onafhankelijk fanconcept.

## Vrijstaande spelers en tegenstanders — 29 oktober 2026

De 32 officiële portretten zijn met transparante maskers vrijstaand gemaakt. Alleen de contourmaskers zijn beeldbewerkt; de RGB-inhoud komt uit de oorspronkelijke clubfoto’s. Publieke uitsneden: dist/media/players-cutout/. De oorspronkelijke clubfoto’s blijven in dist/media/players/ en sources/player-originals/. Dezelfde uitsneden worden gebruikt voor de laatste basiself, de Dream 11 en de spelerskiezer.

Konyaspor-logo: https://konyaspor.org.tr/basin-odasi — officieel aangeboden perslogo, exacte bestandsbron in opponent-logos.json.
Fenerbahçe-logo: https://www.fenerbahce.org/ — officiële clubmedia, exacte bestandsbron in opponent-logos.json.
