# Galatasaray — onafhankelijk fanconcept

Zelfstandige Turkstalige Galatasaray-website in `dist/`. Aparte versie naast het Fenerbahçe-concept; geen officiële opdracht of samenwerking met de club.

## Starten

Node.js vereist. Open deze map en voer `npm start` uit. Preview: http://127.0.0.1:4177/. Geen installatie of build nodig. De bestanden in `dist/` kunnen rechtstreeks naar statische hosting. Gebruik in Turkije een eigen domein.

## Inhoud en functies

- Rood, geel en donker bordeaux; echte clubbeelden, officieel logo en zelf gehoste fonts met Turkse tekens.
- Afteller naar Konyaspor – Galatasaray, 30 oktober 2026, 20.00 TSİ. Gegevens gecontroleerd op 29 oktober; geen live koppeling.
- Vorige derby, Osimhen-sectie en laatste basiself volgens het officiële wedstrijdverslag.
- Elftalbouwer met 32 officiële selectiespelers, alle spelers beschikbaar per positie, zoeken, groepsfilters, dubbele spelers geblokkeerd, laatste basiself en reset.
- Eigen localStorage-sleutel `uluks-gala-favourite-eleven-v1`; raakt Fenerbahçe-keuzes niet aan.
- Drie officiële 2026/27 GSStore-tenues. Links openen de echte winkel; geen betalingen op het concept.
- Supportersclip “Çocukluk Aşkımsın”, volume en uitknop. Geluid staat standaard aan; browsers kunnen een eerste aanraking vereisen.
- WhatsApp-afspraak naar U-LUKSSTUDYO, +90 501 640 14 79, met Turks vooringevuld bericht. Opent uitsluitend een gesprek.
- Drie duidelijk als concept gemarkeerde fanpakketten, zonder verzonnen prijzen of inschrijving.

Optionele achtergrondvideo: voeg `dist/media/stadium-drone.mp4` toe. Zonder video blijft de echte clubfoto zichtbaar.

## Bestanden

`dist/index.html`: inhoud. `style.css`, `official.css`, `gala.css`, `squad-builder.css`: ontwerp. `squad-data.js`: selectie. `squad-state.js`: opstelling. `squad-builder.js`: interactie. `app.js`: navigatie, afteller en slider. `music.js`: audio.

`npm test` controleert opslagherstel, dubbele spelers en de basiself. `node check.mjs` controleert lokale assets, achtergebleven Fenerbahçe-code en het budget van 2 MB.

De technische studio-starterhandleiding en controles zijn bewaard in `starter-reference/`; de zelfstandige fanwebsite gebruikt de bestaande buildloze Fenerbahçe-architectuur.

Niet gecommit, gepusht of gepubliceerd.
