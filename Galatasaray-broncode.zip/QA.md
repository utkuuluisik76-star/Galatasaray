# Controle — 29 oktober 2026

- Publiceerbare bestanden: 1.422.114 bytes inclusief supportersaudio, exclusief optionele achtergrondvideo. Onder 2 MB.
- Lokale assetcontrole: geen ontbrekende verwijzingen.
- Eén H1. Geen horizontale overflow op 390, 768 en 1440 px.
- Geen fout- of waarschuwingsmeldingen in de browserconsole tijdens de controle.
- Geen mislukte geladen afbeeldingen op de gecontroleerde schermen.
- Zoekpaneel toont 32 spelers; zoeken op Osimhen geeft één resultaat.
- Spelerskeuze blijft na herladen staan. Dubbele selectie is geblokkeerd.
- Laatste basiself levert 11 verschillende spelers. Testselecties weer gewist.
- Supportersaudio geladen: duur 30 s; afspelen geverifieerd na gebruikersinteractie.
- Drie betekenisvolle state-tests geslaagd: corrupte opslag, dubbele spelers, geldige laatste basiself.
- WhatsApp-link verwijst naar 905016401479 met Galatasaray-specifieke Turkse tekst. Geen bericht verzonden.
- CSS bevat reduced-motion-afhandeling; volledige aparte reduced-motion/no-JS-browseraudit en Lighthouse/frameprofilering zijn niet uitgevoerd. Geen claims over Lighthouse-scores of Core Web Vitals.
- Alleen lokaal gebouwd; geen deploy, commit of push.
